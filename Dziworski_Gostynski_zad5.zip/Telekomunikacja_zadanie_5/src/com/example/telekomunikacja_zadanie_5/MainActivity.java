package com.example.telekomunikacja_zadanie_5;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Debug;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.util.Pair;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.telekomunikacja_zadanie_5.R.id;

public class MainActivity extends ActionBarActivity implements OnClickListener{
	void addButtons(String btnText,String btnLink){
		
	}
	 private class DownloadWebpageTask extends AsyncTask<String, Void, String> {
		 HashMap<String, String> linksAndTitles;
		 public void readIt(InputStream stream) throws IOException, UnsupportedEncodingException {
			    java.util.Scanner s = new java.util.Scanner(stream).useDelimiter("\\A");
			    String calyKod = s.hasNext() ? s.next() : "";
			    //PARSE
			    String divClassPattern = "<div class=\"question-summary-wrapper\">";
			    String output = "";
			    int divclassPos =-1;
			    linksAndTitles = new HashMap<String, String>();
			    while(divclassPos != 0){
			    	divclassPos=calyKod.indexOf(divClassPattern,divclassPos);
			    	final int titlestart = calyKod.indexOf("<h2><a title=\"",divclassPos) +14 ;
			    	final int linkstart = calyKod.indexOf("href=\"",divclassPos)+6;
			    	final int titleend = calyKod.indexOf("\"",titlestart);
			    	final int linkend = calyKod.indexOf("\">",linkstart);
			    	divclassPos++;
			    	linksAndTitles.put(calyKod.substring(titlestart,titleend), calyKod.substring(linkstart,linkend));
			    }
			}
		 private void downloadUrl(String myurl) throws IOException {
			    InputStream is = null;
			    
			    // Only display the first 500 characters of the retrieved
			    // web page content.
			    try {
			        URL url = new URL(myurl);
			        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			        conn.setReadTimeout(10000 /* milliseconds */);
			        conn.setConnectTimeout(15000 /* milliseconds */);
			        conn.setRequestMethod("GET");
			        conn.setDoInput(true);
			        // Starts the query
			        conn.connect();
			        int response = conn.getResponseCode();
			        Log.d("stad","The response is: " + response);
			        is = conn.getInputStream();
			        readIt(is);
			    } finally {
			        if (is != null) {
			            is.close();
			        } 
			    }
			}
	        @Override
	        protected String doInBackground(String... urls) {
	              
	            // params comes from the execute() call: params[0] is the url.
	            try {
	                downloadUrl(urls[0]);
	                return "Za�adowano";
	            } catch (IOException e) {
	                return "B�ad. By� mo�e z�e url?";
	            }
	        }
	        // onPostExecute displays the results of the AsyncTask.
	        @Override
	        protected void onPostExecute(String result) {
	        	tekst.setText(result);
	        	for(Entry<String, String> entry:linksAndTitles.entrySet()){
	        		final String link = adres+entry.getValue();
	        		if(link.indexOf("questions")==-1) continue;
	        		Log.d("c",link);
	        		Button btn = new Button(MainActivity.this);
	        		btn.setText(entry.getKey());
	        		LinearLayout layout = (LinearLayout) findViewById(R.id.naprzyciski);
		        	layout.addView(btn);
		        	btn.setOnClickListener(new OnClickListener() {
						@Override
						public void onClick(View v) {
							Intent i = new Intent(Intent.ACTION_VIEW,Uri.parse(link));
					    	MainActivity.this.startActivity(i);
						}
					});
	        	}
	       }
	    }
	TextView tekst;
	private final String adres= "http://answers.unity3d.com";
	private Button przycisk;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		przycisk = (Button) findViewById(id.aktywuj);
		przycisk.setOnClickListener(this);
		tekst = (TextView) findViewById(id.poleTekstowe);
		tekst.setText("Witaj");
		}
	@Override
	public void onClick(View v) {
		   ConnectivityManager connMgr = (ConnectivityManager) 
			        getSystemService(Context.CONNECTIVITY_SERVICE);
			    NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
			    if (networkInfo != null && networkInfo.isConnected()) {
			    	LinearLayout layout = (LinearLayout) findViewById(R.id.naprzyciski);
	            	layout.removeAllViews();
			    	tekst.setText("�adowanie");
			    	przycisk.setText("Od�wierz");
			    	new DownloadWebpageTask().execute(adres);
			    } 
			    else {
			    	tekst.setText("Brak polaczenia z internetem");
			    }
	}
}
